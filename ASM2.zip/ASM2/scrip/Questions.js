var Questions = [
    {
        id: 1,
        title: "Câu hỏi 1",
        options: ["A", "B", "C"],
        answer: "A"
    },
    {
        id: 2,
        title: "Câu hỏi 2",
        options: ["D", "E", "F"],
        answer: "D"
    },
    {
        id: 3,
        title: "Câu hỏi 3",
        options: ["G", "H", "I"],
        answer: "G"
    },
    // More questions...
];
