var Subjects = [
    { name: "Lập trình Android nâng cao" },
    { name: "Cơ sở dữ liệu" },
    { name: "Kỹ thuật lập trình" }
];